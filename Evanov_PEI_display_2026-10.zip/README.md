# Créatifs display Evanov · Evanov display creatives

**Poulin Électrique Inc** · https://evanov.poulinelectrique.com ([English](https://evanov.poulinelectrique.com/en/))

## Français

Page de téléchargement des créatifs display pour les deux IO d'Evanov Communications, en français et en anglais.

- **IO 1 – Generac (balise A)** et **IO 2 – Poulin Électrique (balise B)**
- 48 fichiers : 24 JPG et 24 MP4, en 6 formats (300×250, 728×90, 160×600, 300×600, 970×250, 320×50)
- MP4 : H.264, sans son, 14,5 s, moins de 200 Ko, joue une fois. Image de secours : le JPG du même format.
- `Static/` et `Video-MP4/` : les créatifs, classés par IO
- `Evanov_creative_list_FR.csv` (séparateur « ; ») et `Evanov_creative_list_EN.csv` : liste des créatifs avec les URL de clic
- `Proof_*.jpg` : épreuves des images fixes et des vidéos
- `Evanov_PEI_display_2026-10.zip` : tout le contenu en un fichier

La page est publiée par GitHub Pages sur evanov.poulinelectrique.com (fichier `CNAME`). Elle n'est pas indexée par les moteurs de recherche.

## English

Download page for the display creatives for Evanov Communications' two IOs, in French and English.

- **IO 1 – Generac (tag A)** and **IO 2 – Poulin Électrique (tag B)**
- 48 files: 24 JPG and 24 MP4, in 6 sizes (300×250, 728×90, 160×600, 300×600, 970×250, 320×50)
- MP4: H.264, no sound, 14.5 s, under 200 KB, plays once. Backup image: the JPG of the same size.
- `Static/` and `Video-MP4/`: the creatives, by IO
- `Evanov_creative_list_EN.csv` and `Evanov_creative_list_FR.csv` (";" separator): creative list with click-through URLs
- `Proof_*.jpg`: proofs of the static and video creatives
- `Evanov_PEI_display_2026-10.zip`: everything in one file

The page is published by GitHub Pages at evanov.poulinelectrique.com (`CNAME` file). It is hidden from search engines.
